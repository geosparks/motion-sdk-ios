//
//  MotionSDK.h
//  MotionSDK
//
//  Created by GeoSpark Mac 15 on 24/08/20.
//  Copyright © 2020 GeoSpark. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MotionSDK.
FOUNDATION_EXPORT double MotionSDKVersionNumber;

//! Project version string for MotionSDK.
FOUNDATION_EXPORT const unsigned char MotionSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MotionSDK/PublicHeader.h>


